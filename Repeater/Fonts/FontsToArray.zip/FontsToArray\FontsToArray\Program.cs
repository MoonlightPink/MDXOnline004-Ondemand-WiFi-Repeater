﻿namespace FontsToArray {
    internal class Program {
        static void Main(string[] args) {
            {
                var FontWidth = 8;
                var FontName = "OLED_Font_X68000_8x16";
                var bm = new System.Drawing.Bitmap(FontName + ".png");

                using (var wfs = new System.IO.StreamWriter(@"..\" + FontName + ".h")) {
                    wfs.WriteLine("static const u8 " + FontName + "[] PROGMEM ={");
                    for (var idx = 0; idx < bm.Width / FontWidth; idx++) {
                        var Line = "";
                        for (var y = 0; y < bm.Height; y++) {
                            var data = 0x00;
                            for (var x = 0; x < FontWidth; x++) {
                                data <<= 1;
                                if ((bm.GetPixel(idx * FontWidth + x, y).ToArgb() & 0x00ffffff) != 0) { data |= 1; }
                            }
                            Line += "0x" + data.ToString("x2") + ",";
                        }
                        wfs.WriteLine(Line);
                    }
                    wfs.WriteLine("};");
                }
            }

            {
                var FontWidth = 12;
                var FontName = "OLED_Font_X68000_12x24";
                var bm = new System.Drawing.Bitmap(FontName + ".png");

                using (var wfs = new System.IO.StreamWriter(@"..\" + FontName + ".h")) {
                    wfs.WriteLine("static const u16 " + FontName + "[] PROGMEM ={");
                    for (var idx = 0; idx < bm.Width / FontWidth; idx++) {
                        var Line = "";
                        for (var y = 0; y < bm.Height; y++) {
                            var data = 0x00;
                            for (var x = 0; x < FontWidth; x++) {
                                data <<= 1;
                                if ((bm.GetPixel(idx * FontWidth + x, y).ToArgb() & 0x00ffffff) != 0) { data |= 1; }
                            }
                            Line += "0x" + data.ToString("x3") + ",";
                        }
                        wfs.WriteLine(Line);
                    }
                    wfs.WriteLine("};");
                }
            }

        }
    }
}
