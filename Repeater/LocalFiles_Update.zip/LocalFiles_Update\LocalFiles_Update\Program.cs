﻿using System.Text;

namespace LocalFiles_Update {
    internal class Program {
        static void Main(string[] args) {
            var fns = System.IO.Directory.GetFiles("LocalFiles", "*.*", SearchOption.TopDirectoryOnly);

            var strs = new StringBuilder();
            strs.AppendLine(@"static const int LocalFilesCount = " + fns.Length.ToString() + ";");
            strs.AppendLine();

            for (var idx = 0; idx < fns.Length; idx++) {
                var fn = fns[idx];
                byte[] buf;
                using (var rfs = new System.IO.StreamReader(fn)) {
                    buf = new byte[rfs.BaseStream.Length];
                    rfs.BaseStream.Read(buf, 0, buf.Length);
                }
                strs.AppendLine(@"static const int LocalFiles" + idx.ToString() + @"_FileSize = " + buf.Length.ToString() + @";");
                strs.Append(@"static const u8 LocalFiles" + idx.ToString() + @"_Data[LocalFiles" + idx.ToString() + @"_FileSize] PROGMEM = {");
                foreach (var data in buf) {
                    strs.Append("0x" + data.ToString("X2") + ",");
                }
                strs.AppendLine(@"};");
                strs.AppendLine();
            }

            strs.AppendLine(@"static CLocalFile* LocalFiles[LocalFilesCount] = {");
            for (var idx = 0; idx < fns.Length; idx++) {
                var fn = fns[idx];
                strs.AppendLine(@"new CLocalFile(""" + System.IO.Path.GetFileName(fn) + @""", LocalFiles" + idx.ToString() + @"_FileSize, LocalFiles" + idx.ToString() + @"_Data),");
            }

            strs.AppendLine(@"};");

            var wfn = @"LocalFiles.h";

            using (var wfs = new System.IO.StreamWriter(wfn)) {
                wfs.Write(strs.ToString());
            }

            Console.WriteLine(strs.ToString());
            Console.WriteLine(wfn + " writed.");
        }
    }
}
