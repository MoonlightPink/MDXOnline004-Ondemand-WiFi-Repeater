﻿namespace BitmapToPackedArray {
    internal class Program {
        static void Main(string[] args) {
            var ImgName = "Image_X68000Logo";

            var bm = new System.Drawing.Bitmap(ImgName + @".png");

            using (var wfs = new System.IO.StreamWriter(@"..\" + ImgName + @".h")) {
                var blkh = bm.Height / 8;

                wfs.WriteLine("static const int " + ImgName + "_Width=" + bm.Width.ToString() + ";");
                wfs.WriteLine("static const int " + ImgName + "_BlockHeight=" + blkh.ToString() + ";");

                wfs.WriteLine("static const u8 " + ImgName + "[] PROGMEM ={");
                for (var blky = 0; blky < blkh; blky++) {
                    var Line = "";
                    for (var x = 0; x < bm.Width; x++) {
                        var data = 0x00;
                        for (var y = 0; y < 8; y++) {
                            data <<= 1;
                            if ((bm.GetPixel(x, blky * 8 + (7 - y)).ToArgb() & 0x00ffffff) != 0) { data |= 1; }
                        }
                        Line += "0x" + data.ToString("x2") + ",";
                    }
                    wfs.WriteLine(Line);
                }
                wfs.WriteLine("};");
            }

        }
    }
}
